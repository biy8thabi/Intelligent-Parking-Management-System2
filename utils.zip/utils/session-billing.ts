// Mock hourly rate for fee calculation — Phase 11 would replace this
// with whatever real pricing rule the backend applies (which may not
// even be a flat hourly rate). Chosen to roughly match the fee/duration
// ratio already used in constants/mock-data.ts's history examples.
export const MOCK_HOURLY_RATE = 10;

export function calculateFee(durationMs: number): number {
  const hours = durationMs / (1000 * 60 * 60);
  return Math.round(hours * MOCK_HOURLY_RATE * 100) / 100;
}

export function formatCurrency(amount: number): string {
  return `R${amount.toFixed(2)}`;
}
