export function isValidEmail(value: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
}

/** Accepts common phone formats, e.g. "+27 82 123 4567" — just checks for enough digits. */
export function isValidPhone(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  return digits.length >= 9;
}

export function isValidVehicleReg(value: string): boolean {
  return value.trim().length >= 3;
}
