// MOCK DATA, fact-checked against Gateway's own site (gatewayworld.co.za)
// and independent sources on 2026-09-23. What's actually verified real:
//   - Mall name, location, ~4 floor count, ~12,000 bays, anchors
//     (Checkers Hyper, Pick n Pay Hyper, Woolworths Food, Edgars,
//     Nu Metro Cinema — Nu Metro replaced Ster-Kinekor there in Oct 2025)
//   - Entrances are NUMBERED (Entrance 1, 3, 5, 8 confirmed on the
//     mall's own store-listing pages) — not directionally named
//   - Parkades are LETTERED (Parkade B, Parkade G both confirmed) and
//     use "P" + number level naming (P2, P5 both confirmed real)
//   - One specific real fact: increased Special Needs/accessibility
//     bays are located "near Entrance 5, Ground Floor, at Parkade B"
//     (gatewayworld.co.za/secure-parking/) — reflected below on the
//     Ground Floor's Entrance 5 note.
//
// What's still an invented simplification for this demo:
//   - Which entrance number sits on which floor, and which store each
//     one serves — the real mall has far more entrances (8+) spread
//     across multiple separate parkade buildings (A, B, G, and likely
//     others), each with their own internal levels. Modelling all of
//     that is out of scope for this app; we simplify to one
//     representative 4-level structure ("Parkade B") and reuse real
//     naming conventions rather than inventing fictional ones.
//   - Which floor each store sits on.
//
// Phase 11 would replace this whole file with a real GET
// /parking-spaces call per venue.

export const MALL_NAME = 'Gateway Theatre of Shopping';
export const MALL_LOCATION = 'Umhlanga, Durban';

export type BayStatus = 'available' | 'occupied' | 'disabled';

export type ParkingBay = {
  id: string;
  spotNumber: string; // parking_spaces.zone + bay_number, combined
  status: BayStatus; // parking_spaces.status
  gateId: string; // which of the floor's gates this bay is nearest to
};

export type GateKind = 'entry' | 'exit' | 'entry-exit';

export type Gate = {
  id: string;
  label: string; // e.g. "Entrance 5" — real Gateway numbering convention
  kind: GateKind;
  nearStore: string; // which anchor store this entrance serves (invented pairing)
  /** A genuinely sourced fact about this specific entrance, if any. */
  note?: string;
};

export type MallFloor = {
  id: string;
  label: string; // e.g. "P1" — real Gateway parking-level naming convention
  sublabel: string; // e.g. "Parkade B — P1 Level"
  stores: string[];
  gates: Gate[];
  bays: ParkingBay[];
};

function makeBays(
  prefix: string,
  count: number,
  disabledIndices: number[],
  gateIds: [string, string]
): ParkingBay[] {
  return Array.from({ length: count }, (_, i) => {
    const spotNumber = `${prefix}-${String(i + 1).padStart(3, '0')}`;
    const status: BayStatus = disabledIndices.includes(i)
      ? 'disabled'
      : Math.random() < 0.35
        ? 'occupied'
        : 'available';
    // First half of the run is nearest the first gate, second half the second.
    const gateId = i < count / 2 ? gateIds[0] : gateIds[1];
    return { id: spotNumber, spotNumber, status, gateId };
  });
}

export const INITIAL_FLOORS: MallFloor[] = [
  {
    id: 'p1',
    label: 'P1',
    sublabel: 'Parkade B — P1 Level',
    stores: ['Checkers Hyper', 'Pick n Pay Hyper'],
    gates: [
      { id: 'p1-gate-a', label: 'Entrance 1', kind: 'entry-exit', nearStore: 'Checkers Hyper' },
      { id: 'p1-gate-b', label: 'Entrance 2', kind: 'entry-exit', nearStore: 'Pick n Pay Hyper' },
    ],
    bays: makeBays('P1', 12, [0], ['p1-gate-a', 'p1-gate-b']),
  },
  {
    id: 'gf',
    label: 'GF',
    sublabel: 'Parkade B — Ground Floor',
    stores: ['Woolworths Food', 'Edgars'],
    gates: [
      {
        id: 'gf-gate-a',
        label: 'Entrance 5',
        kind: 'entry-exit',
        nearStore: 'Woolworths Food',
        note: 'Real Gateway policy: extra accessibility/Special Needs bays are sited here.',
      },
      { id: 'gf-gate-b', label: 'Entrance 6', kind: 'entry-exit', nearStore: 'Edgars' },
    ],
    bays: makeBays('GF', 12, [1], ['gf-gate-a', 'gf-gate-b']),
  },
  {
    id: 'l1',
    label: 'P2',
    sublabel: 'Parkade B — P2 Level',
    stores: ['Nu Metro Cinema', 'Food Court'],
    gates: [
      { id: 'l1-gate-a', label: 'Entrance 3', kind: 'entry', nearStore: 'Nu Metro Cinema' },
      { id: 'l1-gate-b', label: 'Entrance 4', kind: 'exit', nearStore: 'Food Court' },
    ],
    bays: makeBays('P2', 10, [0, 5], ['l1-gate-a', 'l1-gate-b']),
  },
  {
    id: 'l2',
    label: 'P3',
    sublabel: 'Parkade B — P3 Level',
    stores: ['Arcade & Entertainment', 'Gym'],
    gates: [
      { id: 'l2-gate-a', label: 'Entrance 7', kind: 'entry-exit', nearStore: 'Arcade & Entertainment' },
      { id: 'l2-gate-b', label: 'Entrance 8', kind: 'entry-exit', nearStore: 'Gym' },
    ],
    bays: makeBays('P3', 10, [], ['l2-gate-a', 'l2-gate-b']),
  },
];

export function floorLabel(floor: Pick<MallFloor, 'label' | 'sublabel'>): string {
  return `${floor.label} · ${floor.sublabel}`;
}

/**
 * Flips one random available<->occupied bay across all floors, as a
 * stand-in for other shoppers arriving/leaving. Never touches
 * accessibility bays (fixed category) or the bay the current user has
 * parked in. Phase 11 replaces this whole simulation with a real
 * subscription (websocket/polling) to the backend's live bay status.
 */
export function flipRandomBay(
  floors: MallFloor[],
  yourBay: { floorLabel: string; bayLabel: string } | null
): MallFloor[] {
  const eligible: { floorIndex: number; bayIndex: number }[] = [];

  floors.forEach((floor, floorIndex) => {
    floor.bays.forEach((bay, bayIndex) => {
      if (bay.status === 'disabled') return;
      if (yourBay && yourBay.floorLabel === floorLabel(floor) && yourBay.bayLabel === bay.spotNumber) {
        return;
      }
      eligible.push({ floorIndex, bayIndex });
    });
  });

  if (eligible.length === 0) return floors;

  const pick = eligible[Math.floor(Math.random() * eligible.length)];

  return floors.map((floor, floorIndex) => {
    if (floorIndex !== pick.floorIndex) return floor;
    return {
      ...floor,
      bays: floor.bays.map((bay, bayIndex) =>
        bayIndex === pick.bayIndex
          ? { ...bay, status: bay.status === 'available' ? 'occupied' : 'available' }
          : bay
      ),
    };
  });
}
