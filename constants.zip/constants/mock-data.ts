// MOCK DATA — Phase 11 replaces this with a real call to services/api.ts
// (GET /me and GET /sessions/active). Shapes below mirror the shared
// Supabase schema (parking_sessions, parking_spaces) so the swap is
// mostly just deleting this file and wiring the real fetch.

export type MockDriver = {
  fullName: string;
  email: string; // users.email
  phone: string; // users.phone_number
  // Mocked here — the `users` table doesn't have a vehicle_reg column yet
  // (flagged during Phase 1 inspection). Swap this out once that's resolved.
  vehicleReg: string;
};

export const mockDriver: MockDriver = {
  fullName: 'Thabo Molefe',
  email: 'thabo.molefe@email.com',
  phone: '+27 82 123 4567',
  vehicleReg: 'CA 123-456 GP',
};

// The active session itself now lives in contexts/session-context.tsx,
// since it's shared live state (Find Parking writes it, Home and
// Active Session read it) rather than static display data.

// The building-wide availability summary is now computed live from
// constants/mall-data.ts (INITIAL_FLOORS) inside the Find Parking
// screen, rather than kept as a separate static figure here.

// The ticket itself (ticket_code, active/pending status) now lives in
// contexts/session-context.tsx, derived from the live reservation/session
// rather than kept as separate static display data.

// Mirrors a join of parking_sessions + parking_spaces, filtered to
// session_status = 'completed', most recent first. Phase 11 replaces
// this with GET /sessions/history.
export type MockHistoryEntry = {
  id: string;
  date: string;
  entryTime: string;
  exitTime: string;
  duration: string;
  bayLabel: string;
  fee: string; // parking_sessions.fee_amount, pre-formatted for now
};

export const mockHistory: MockHistoryEntry[] = [
  {
    id: 'h1',
    date: '15 July 2026',
    entryTime: '08:10 AM',
    exitTime: '11:00 AM',
    duration: '2h 50m',
    bayLabel: 'B-14',
    fee: 'R28.50',
  },
  {
    id: 'h2',
    date: '12 July 2026',
    entryTime: '14:30 PM',
    exitTime: '16:45 PM',
    duration: '2h 15m',
    bayLabel: 'A-07',
    fee: 'R22.50',
  },
  {
    id: 'h3',
    date: '8 July 2026',
    entryTime: '09:00 AM',
    exitTime: '10:30 AM',
    duration: '1h 30m',
    bayLabel: 'A-03',
    fee: 'R12.00',
  },
];

// Mirrors notifications (message, type, is_read, created_at), most
// recent first. Phase 11 replaces this with GET /notifications.
export type MockNotification = {
  id: string;
  title: string;
  message: string;
  timeAgo: string; // pre-formatted from created_at for now
  isRead: boolean; // notifications.is_read
};

export const mockNotifications: MockNotification[] = [
  {
    id: 'n1',
    title: 'Parking Session Started',
    message: 'Your session at Bay B-14 has begun. Remember to display your QR code.',
    timeAgo: '10 minutes ago',
    isRead: false,
  },
  {
    id: 'n2',
    title: 'Parking Area Nearly Full',
    message: 'Only 5 spaces remaining in the parking area.',
    timeAgo: '1 hour ago',
    isRead: false,
  },
  {
    id: 'n3',
    title: 'QR Code Generated',
    message: 'Your parking QR code PKG-2026-0042 is ready.',
    timeAgo: '2 hours ago',
    isRead: false,
  },
  {
    id: 'n4',
    title: 'Session Completed',
    message: 'Your parking session at Bay A-07 ended. Duration: 2h 15m.',
    timeAgo: 'Yesterday',
    isRead: true,
  },
];
