import { useMemo } from 'react';
import { ScrollView, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { HistorySessionCard } from '@/components/history-session-card';
import { ScreenHeader } from '@/components/screen-header';
import { ThemedText } from '@/components/themed-text';
import { Colors } from '@/constants/theme';
import { mockHistory, type MockHistoryEntry } from '@/constants/mock-data';
import { useSession } from '@/contexts/session-context';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { formatClockTime, formatDate, formatDuration } from '@/utils/format-duration';
import { formatCurrency } from '@/utils/session-billing';

export default function HistoryScreen() {
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'light'];
  const { completedSessions } = useSession();

  // Real sessions you've actually completed in this app run, converted
  // into the same shape as the static examples, newest first.
  const realEntries: MockHistoryEntry[] = useMemo(
    () =>
      completedSessions.map((session) => ({
        id: session.id,
        date: formatDate(session.entryTimestamp),
        entryTime: formatClockTime(session.entryTimestamp),
        exitTime: formatClockTime(session.exitTimestamp),
        duration: formatDuration(session.durationMs),
        bayLabel: session.bayLabel,
        fee: formatCurrency(session.fee),
      })),
    [completedSessions]
  );

  const allEntries = [...realEntries, ...mockHistory];

  return (
    <SafeAreaView edges={['top']} style={[styles.flex, { backgroundColor: colors.background }]}>
      <ScreenHeader title="Parking History" />

      {allEntries.length === 0 ? (
        <ThemedText style={styles.emptyText}>No completed sessions yet.</ThemedText>
      ) : (
        <ScrollView contentContainerStyle={styles.scrollContent}>
          {allEntries.map((entry) => (
            <HistorySessionCard key={entry.id} entry={entry} />
          ))}
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 40 },
  emptyText: { textAlign: 'center', marginTop: 40, opacity: 0.6 },
});
