import { ScrollView, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { NotificationCard } from '@/components/notification-card';
import { ScreenHeader } from '@/components/screen-header';
import { ThemedText } from '@/components/themed-text';
import { Colors } from '@/constants/theme';
import { mockNotifications } from '@/constants/mock-data';
import { useColorScheme } from '@/hooks/use-color-scheme';

export default function NotificationsScreen() {
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'light'];

  const unreadCount = mockNotifications.filter((n) => !n.isRead).length;

  return (
    <SafeAreaView edges={['top']} style={[styles.flex, { backgroundColor: colors.background }]}>
      <ScreenHeader title="Notifications" badge={unreadCount} />

      {mockNotifications.length === 0 ? (
        <ThemedText style={styles.emptyText}>No notifications yet.</ThemedText>
      ) : (
        <ScrollView contentContainerStyle={styles.scrollContent}>
          {mockNotifications.map((notification) => (
            <NotificationCard key={notification.id} notification={notification} />
          ))}
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  scrollContent: { paddingBottom: 40 },
  emptyText: { textAlign: 'center', marginTop: 40, opacity: 0.6 },
});
