import { ScrollView, StyleSheet, Switch, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { OptionSelector } from '@/components/option-selector';
import { ScreenHeader } from '@/components/screen-header';
import { ThemedText } from '@/components/themed-text';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { Colors } from '@/constants/theme';
import { useAccessibility } from '@/contexts/accessibility-context';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useThemeStyles } from '@/hooks/use-theme-styles';

export default function AccessibilitySettingsScreen() {
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'light'];
  const {
    themeOverride,
    setThemeOverride,
    fontScaleOption,
    setFontScaleOption,
    highContrast,
    setHighContrast,
    readAloudEnabled,
    setReadAloudEnabled,
    speak,
  } = useAccessibility();

  return (
    <SafeAreaView edges={['top']} style={[styles.flex, { backgroundColor: colors.background }]}>
      <ScreenHeader title="Accessibility Settings" />
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <ThemedText style={styles.intro}>
          These settings apply across the whole app and take effect immediately.
        </ThemedText>

        <Section icon="circle.grid.2x2.fill" title="Appearance">
          <ThemedText style={styles.label}>Theme</ThemedText>
          <OptionSelector
            options={[
              { value: 'light', label: 'Light' },
              { value: 'dark', label: 'Dark' },
              { value: 'system', label: 'System' },
            ]}
            selected={themeOverride}
            onSelect={setThemeOverride}
          />
        </Section>

        <Section icon="textformat.size" title="Text Size">
          <OptionSelector
            options={[
              { value: 'default', label: 'Default' },
              { value: 'large', label: 'Large' },
              { value: 'extraLarge', label: 'Extra Large' },
            ]}
            selected={fontScaleOption}
            onSelect={setFontScaleOption}
          />
        </Section>

        <Section icon="circle.lefthalf.filled" title="High Contrast">
          <View style={styles.switchRow}>
            <ThemedText style={styles.switchLabel}>
              Boost text contrast for low-vision users
            </ThemedText>
            <Switch value={highContrast} onValueChange={setHighContrast} accessibilityLabel="High contrast" />
          </View>
          <ThemedText style={styles.note}>
            This raises muted/secondary text to full opacity throughout the app. It doesn&apos;t yet
            change border colors on every card — that&apos;s a known gap, not finished polish.
          </ThemedText>
        </Section>

        <Section icon="speaker.wave.2.fill" title="Read Aloud">
          <View style={styles.switchRow}>
            <ThemedText style={styles.switchLabel}>
              Show a speaker button on key screens to read content aloud
            </ThemedText>
            <Switch
              value={readAloudEnabled}
              onValueChange={setReadAloudEnabled}
              accessibilityLabel="Read aloud"
            />
          </View>
          <ThemedText
            style={[styles.testLink, { color: colors.tint }]}
            accessibilityRole="button"
            onPress={() =>
              speak('This is a test of the read aloud feature. You can adjust its speed in your device settings.')
            }>
            Test read aloud
          </ThemedText>
        </Section>

        <Section icon="checkmark.circle.fill" title="Built-in support">
          <ThemedText style={styles.note}>
            Every button, field, and status indicator in this app has labels for screen readers
            (VoiceOver on iOS, TalkBack on Android) — that&apos;s the standard, correct way to
            support blind users, rather than this app trying to build its own screen reader.
          </ThemedText>
          <ThemedText style={[styles.note, styles.noteSpacing]}>
            Nothing in the app depends on sound: every status is shown with an icon, a color, and
            text together — never color or audio alone — so it works the same with the sound off.
          </ThemedText>
        </Section>
      </ScrollView>
    </SafeAreaView>
  );
}

function Section({
  icon,
  title,
  children,
}: {
  icon: Parameters<typeof IconSymbol>[0]['name'];
  title: string;
  children: React.ReactNode;
}) {
  const colorScheme = useColorScheme();
  const tint = Colors[colorScheme ?? 'light'].tint;
  const { cardBorder } = useThemeStyles();

  return (
    <View style={[styles.section, cardBorder]}>
      <View style={styles.sectionHeader}>
        <IconSymbol name={icon} size={18} color={tint} />
        <ThemedText style={styles.sectionTitle}>{title}</ThemedText>
      </View>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 60 },
  intro: { opacity: 0.7, fontSize: 14, marginBottom: 24 },
  section: {
    borderWidth: 1,
    borderRadius: 14,
    padding: 16,
    marginBottom: 16,
  },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 },
  sectionTitle: { fontSize: 16, fontWeight: '700' },
  label: { fontSize: 13, opacity: 0.6, marginBottom: 8 },
  switchRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  switchLabel: { flex: 1, fontSize: 14 },
  note: { fontSize: 13, opacity: 0.65, lineHeight: 19 },
  noteSpacing: { marginTop: 10 },
  testLink: { fontSize: 14, fontWeight: '700', marginTop: 12 },
});
