import { router } from 'expo-router';
import { useEffect, useMemo, useState } from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { FloorSelector } from '@/components/floor-selector';
import { GateList } from '@/components/gate-list';
import { ParkingSpotGrid } from '@/components/parking-spot-grid';
import { PrimaryButton } from '@/components/primary-button';
import { StoreChipRow } from '@/components/store-chip-row';
import { ThemedText } from '@/components/themed-text';
import { Colors } from '@/constants/theme';
import {
  flipRandomBay,
  floorLabel,
  INITIAL_FLOORS,
  MALL_LOCATION,
  MALL_NAME,
  type MallFloor,
} from '@/constants/mall-data';
import { useSession } from '@/contexts/session-context';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useThemeStyles } from '@/hooks/use-theme-styles';

const STATUS_COLORS = {
  available: '#12B76A',
  occupied: '#F04438',
  disabled: '#F79009',
};

const LIVE_UPDATE_INTERVAL_MS = 4000;

export default function FindParkingScreen() {
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'light'];
  const { activeSession, pendingReservation, reserveSpot } = useSession();
  const { borderColor } = useThemeStyles();

  const [floors, setFloors] = useState<MallFloor[]>(INITIAL_FLOORS);
  const [selectedFloorId, setSelectedFloorId] = useState(INITIAL_FLOORS[0].id);
  const [selectedBayId, setSelectedBayId] = useState<string | null>(null);

  // A spot counts as "claimed" whether it's already an active (scanned-in)
  // session or just reserved and awaiting the gate scan — either way it
  // shouldn't flip in the live simulation or be selectable by anyone else.
  const claimedBay = activeSession ?? pendingReservation;
  const yourBay = claimedBay ? { floorLabel: claimedBay.floorLabel, bayLabel: claimedBay.bayLabel } : null;
  const yourBayPending = !activeSession && !!pendingReservation;

  // Simulates other shoppers arriving/leaving — see flipRandomBay's
  // comment in constants/mall-data.ts for what this stands in for.
  useEffect(() => {
    const id = setInterval(() => {
      setFloors((prev) => flipRandomBay(prev, yourBay));
    }, LIVE_UPDATE_INTERVAL_MS);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [yourBay?.floorLabel, yourBay?.bayLabel]);

  const selectedFloor = floors.find((f) => f.id === selectedFloorId) ?? floors[0];
  const selectedBay = selectedFloor.bays.find((b) => b.id === selectedBayId) ?? null;
  const yourBayIdOnThisFloor =
    yourBay && yourBay.floorLabel === floorLabel(selectedFloor)
      ? (selectedFloor.bays.find((b) => b.spotNumber === yourBay.bayLabel)?.id ?? null)
      : null;

  const totals = useMemo(() => {
    const acc = { available: 0, occupied: 0, disabled: 0 };
    floors.forEach((floor) => floor.bays.forEach((bay) => acc[bay.status]++));
    return acc;
  }, [floors]);

  function handleSelectFloor(floorId: string) {
    setSelectedFloorId(floorId);
    setSelectedBayId(null);
  }

  function handleSelectBay(bayId: string) {
    setSelectedBayId((prev) => (prev === bayId ? null : bayId));
  }

  function handleConfirm() {
    if (!selectedBay) return;
    // Reserving issues a ticket, but the session only becomes active once
    // the QR is scanned at the gate — see My Ticket's "Simulate Scan".
    reserveSpot(floorLabel(selectedFloor), selectedBay.spotNumber);
    setSelectedBayId(null);
    router.push('/(tabs)/my-ticket');
  }

  return (
    <SafeAreaView edges={['top']} style={[styles.flex, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[styles.scrollContent, selectedBay ? styles.scrollContentWithBar : undefined]}>
        <ThemedText type="title" style={styles.title}>
          Find Parking
        </ThemedText>
        <ThemedText style={styles.mallLine}>
          {MALL_NAME} · {MALL_LOCATION}
        </ThemedText>

        <View style={styles.summaryRow}>
          <SummaryDot color={STATUS_COLORS.available} label={`${totals.available} Available`} />
          <SummaryDot color={STATUS_COLORS.occupied} label={`${totals.occupied} Occupied`} />
          <SummaryDot color={STATUS_COLORS.disabled} label={`${totals.disabled} Accessible`} />
        </View>

        <ThemedText style={styles.sectionTitle}>Select a Floor</ThemedText>
        <FloorSelector floors={floors} selectedFloorId={selectedFloorId} onSelect={handleSelectFloor} />

        <ThemedText style={styles.sectionTitle}>Shops on {selectedFloor.label}</ThemedText>
        <StoreChipRow stores={selectedFloor.stores} />

        <ThemedText style={styles.sectionTitle}>Entry & Exit Points</ThemedText>
        <GateList gates={selectedFloor.gates} />

        <View style={styles.spotHeaderRow}>
          <ThemedText style={styles.sectionTitle}>Choose Your Spot</ThemedText>
          <View style={styles.liveBadge}>
            <View style={styles.liveDot} />
            <ThemedText style={styles.liveText}>Live</ThemedText>
          </View>
        </View>
        <ThemedText style={styles.groupHint}>Bays are grouped by their nearest gate.</ThemedText>

        {selectedFloor.gates.map((gate) => {
          const gateBays = selectedFloor.bays.filter((bay) => bay.gateId === gate.id);
          if (gateBays.length === 0) return null;
          return (
            <View key={gate.id} style={styles.gateGroup}>
              <ThemedText style={styles.gateGroupTitle}>Near {gate.label}</ThemedText>
              <ParkingSpotGrid
                bays={gateBays}
                selectedBayId={selectedBayId}
                yourBayId={yourBayIdOnThisFloor}
                yourBayPending={yourBayPending}
                onSelect={handleSelectBay}
              />
            </View>
          );
        })}

        <View style={styles.legend}>
          <LegendRow color={STATUS_COLORS.available} label="Available" />
          <LegendRow color={STATUS_COLORS.occupied} label="Occupied" />
          <LegendRow color={STATUS_COLORS.disabled} label="Accessible (requires permit badge)" />
          {yourBayIdOnThisFloor && (
            <LegendRow
              color={colors.tint}
              label={yourBayPending ? 'Your reserved spot (scan to enter)' : 'Your parked spot'}
            />
          )}
        </View>
      </ScrollView>

      {selectedBay && (
        <View style={[styles.confirmBar, { backgroundColor: colors.background, borderTopColor: borderColor }]}>
          <View style={styles.confirmTextBlock}>
            <ThemedText style={styles.confirmSpot}>{selectedBay.spotNumber}</ThemedText>
            <ThemedText style={styles.confirmFloor}>
              {selectedFloor.label} · {selectedFloor.sublabel}
            </ThemedText>
          </View>
          <View style={styles.confirmButtonWrap}>
            <PrimaryButton label="Confirm & Get Ticket" onPress={handleConfirm} />
          </View>
        </View>
      )}
    </SafeAreaView>
  );
}

function SummaryDot({ color, label }: { color: string; label: string }) {
  return (
    <View style={styles.summaryItem}>
      <View style={[styles.summaryDot, { backgroundColor: color }]} />
      <ThemedText style={styles.summaryLabel}>{label}</ThemedText>
    </View>
  );
}

function LegendRow({ color, label }: { color: string; label: string }) {
  return (
    <View style={styles.legendRow}>
      <View style={[styles.legendDot, { backgroundColor: color }]} />
      <ThemedText style={styles.legendLabel}>{label}</ThemedText>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 40 },
  scrollContentWithBar: { paddingBottom: 110 },
  title: { fontSize: 24, marginBottom: 2 },
  mallLine: { fontSize: 14, opacity: 0.6, marginBottom: 16 },
  summaryRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 16, marginBottom: 24 },
  summaryItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  summaryDot: { width: 8, height: 8, borderRadius: 4 },
  summaryLabel: { fontSize: 13, fontWeight: '600', opacity: 0.8 },
  sectionTitle: { fontSize: 16, fontWeight: '700', marginBottom: 10, marginTop: 4 },
  spotHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  liveBadge: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  liveDot: { width: 7, height: 7, borderRadius: 3.5, backgroundColor: '#12B76A' },
  liveText: { fontSize: 12, fontWeight: '700', color: '#12B76A' },
  groupHint: { fontSize: 12, opacity: 0.55, marginBottom: 16 },
  gateGroup: { marginBottom: 20 },
  gateGroupTitle: { fontSize: 13, fontWeight: '700', opacity: 0.7, marginBottom: 10 },
  legend: { gap: 8, marginTop: 18 },
  legendRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  legendDot: { width: 12, height: 12, borderRadius: 4 },
  legendLabel: { fontSize: 13, opacity: 0.75 },
  confirmBar: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 14,
    paddingBottom: 24,
    borderTopWidth: 1,
    gap: 12,
  },
  confirmTextBlock: { flex: 1 },
  confirmSpot: { fontSize: 18, fontWeight: '800' },
  confirmFloor: { fontSize: 13, opacity: 0.6 },
  confirmButtonWrap: { width: 190 },
});
