import { router } from 'expo-router';
import QRCode from 'react-native-qrcode-svg';
import { ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { PrimaryButton } from '@/components/primary-button';
import { ReadAloudButton } from '@/components/read-aloud-button';
import { ThemedText } from '@/components/themed-text';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { Colors } from '@/constants/theme';
import { mockDriver } from '@/constants/mock-data';
import { useSession } from '@/contexts/session-context';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useThemeStyles } from '@/hooks/use-theme-styles';
import { formatDuration } from '@/utils/format-duration';
import { formatCurrency } from '@/utils/session-billing';

const ACTIVE_GREEN = '#12B76A';
const PENDING_AMBER = '#F79009';
const EXIT_BLUE = '#2E90FA';

export default function MyTicketScreen() {
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'light'];
  const { pendingReservation, activeSession, pendingExit, confirmEntry, confirmExit } = useSession();
  const { surface } = useThemeStyles();

  // No ticket at all — nothing reserved, entered, or ended.
  if (!pendingReservation && !activeSession && !pendingExit) {
    return (
      <SafeAreaView edges={['top']} style={[styles.flex, { backgroundColor: colors.background }]}>
        <ScrollView contentContainerStyle={[styles.scrollContent, styles.emptyContent]}>
          <IconSymbol name="qrcode" size={48} color="#98A2B3" />
          <ThemedText type="title" style={styles.emptyTitle}>
            No Ticket Yet
          </ThemedText>
          <ThemedText style={styles.emptyNote}>
            Pick a parking spot to get your QR ticket for the gate.
          </ThemedText>
          <View style={styles.emptyButtonWrap}>
            <PrimaryButton label="Find Parking" onPress={() => router.push('/(tabs)/find-parking')} />
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  // Mid-session, ticket already used to enter — nothing to scan right
  // now. End the session from Active Session to get the exit QR.
  if (activeSession && !pendingExit) {
    return (
      <SafeAreaView edges={['top']} style={[styles.flex, { backgroundColor: colors.background }]}>
        <ScrollView contentContainerStyle={[styles.scrollContent, styles.emptyContent]}>
          <IconSymbol name="checkmark.circle.fill" size={48} color={ACTIVE_GREEN} />
          <ThemedText type="title" style={styles.emptyTitle}>
            You&apos;re Parked In
          </ThemedText>
          <ThemedText style={styles.emptyNote}>
            Your ticket for {activeSession.bayLabel} was used to enter. End your session to get a
            fresh QR code for the exit boom gate.
          </ThemedText>
          <View style={styles.emptyButtonWrap}>
            <PrimaryButton label="View Active Session" onPress={() => router.push('/active-session')} />
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  const isExit = !!pendingExit;
  const session = pendingExit ?? pendingReservation!;
  const pillColor = isExit ? EXIT_BLUE : PENDING_AMBER;
  const pillLabel = isExit ? 'Scan to Exit' : 'Awaiting Entry Scan';

  function handleSimulateScan() {
    if (isExit) {
      confirmExit();
    } else {
      confirmEntry();
    }
    router.replace('/(tabs)');
  }

  const spokenSummary = isExit
    ? `Exit ticket for bay ${session.bayLabel}. Your session lasted ${formatDuration(pendingExit!.durationMs)}, and the amount due is ${formatCurrency(pendingExit!.fee)}. Present this code at the boom gate to leave.`
    : `Entry ticket for bay ${session.bayLabel}. Present this code at the parking access point to begin your session.`;

  return (
    <SafeAreaView edges={['top']} style={[styles.flex, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.titleRow}>
          <ThemedText type="title" style={styles.title}>
            {isExit ? 'Exit QR Code' : 'My Parking QR Code'}
          </ThemedText>
          <ReadAloudButton text={spokenSummary} />
        </View>

        <View style={[styles.qrBox, { borderColor: colors.text }]}>
          {/*
            The QR encodes the ticket_code, issued the moment the spot was
            reserved, and reused unchanged for the exit scan — the same
            physical ticket a real system would issue once per session.
          */}
          <QRCode value={session.ticketCode} size={220} color={colors.text} backgroundColor="transparent" />
        </View>

        <ThemedText type="subtitle" style={styles.driverName}>
          {mockDriver.fullName}
        </ThemedText>
        <ThemedText style={styles.metaLine}>Vehicle: {mockDriver.vehicleReg}</ThemedText>
        <ThemedText style={styles.metaLine}>Ticket ID: {session.ticketCode}</ThemedText>
        <ThemedText style={styles.metaLine}>
          Bay: {session.bayLabel} · {session.floorLabel}
        </ThemedText>
        {isExit && (
          <>
            <ThemedText style={styles.metaLine}>
              Time Parked: {formatDuration(pendingExit!.durationMs)}
            </ThemedText>
            <ThemedText style={[styles.metaLine, styles.feeLine]}>
              Amount Due: {formatCurrency(pendingExit!.fee)}
            </ThemedText>
          </>
        )}

        <View style={[styles.statusPill, { backgroundColor: `${pillColor}1A` }]}>
          <View style={[styles.dot, { backgroundColor: pillColor }]} />
          <ThemedText style={[styles.statusPillText, { color: pillColor }]}>{pillLabel}</ThemedText>
        </View>

        <View style={[styles.infoBanner, surface]}>
          <IconSymbol name="exclamationmark.triangle.fill" size={18} color="#F79009" />
          <ThemedText style={styles.infoBannerText}>
            {isExit
              ? 'Present this QR code at the payment toll or boom gate to exit.'
              : 'Present this QR code at the parking access point for entry.'}
          </ThemedText>
        </View>

        <View style={styles.scanButtonWrap}>
          <PrimaryButton
            label={isExit ? 'Simulate Exit Scan at Boom Gate' : 'Simulate Scan at Gate'}
            onPress={handleSimulateScan}
          />
          <ThemedText style={styles.scanNote}>
            In the real app, the gate scanner confirms this automatically &mdash; this button
            stands in for that hardware step until it&apos;s wired up.
          </ThemedText>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 40, alignItems: 'center' },
  titleRow: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  title: { fontSize: 22 },
  qrBox: {
    borderWidth: 2,
    borderRadius: 20,
    padding: 24,
    marginBottom: 20,
  },
  driverName: { fontSize: 20, marginBottom: 4 },
  metaLine: { fontSize: 15, opacity: 0.7, marginBottom: 4 },
  feeLine: { fontWeight: '700', opacity: 1 },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 24,
    marginTop: 12,
  },
  dot: { width: 8, height: 8, borderRadius: 4 },
  statusPillText: { fontWeight: '700', fontSize: 14 },
  infoBanner: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    borderRadius: 12,
    padding: 16,
    marginTop: 28,
    width: '100%',
  },
  infoBannerText: { flex: 1, fontSize: 14, opacity: 0.8, lineHeight: 20 },
  scanButtonWrap: { width: '100%', marginTop: 20, alignItems: 'center', gap: 10 },
  scanNote: { fontSize: 12, opacity: 0.55, textAlign: 'center', paddingHorizontal: 12 },
  emptyContent: { flexGrow: 1, justifyContent: 'center', gap: 12 },
  emptyTitle: { fontSize: 20 },
  emptyNote: { textAlign: 'center', opacity: 0.7, paddingHorizontal: 20 },
  emptyButtonWrap: { width: 220, marginTop: 8 },
});
