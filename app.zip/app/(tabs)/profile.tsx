import { router } from 'expo-router';
import { ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { PrimaryButton } from '@/components/primary-button';
import { ProfileRow } from '@/components/profile-row';
import { ThemedText } from '@/components/themed-text';
import { Colors } from '@/constants/theme';
import { mockDriver } from '@/constants/mock-data';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useThemeStyles } from '@/hooks/use-theme-styles';

function getInitials(fullName: string): string {
  const parts = fullName.trim().split(/\s+/);
  const first = parts[0]?.[0] ?? '';
  const last = parts.length > 1 ? parts[parts.length - 1][0] : '';
  return (first + last).toUpperCase();
}

export default function ProfileScreen() {
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'light'];
  const { cardBorder } = useThemeStyles();

  function handleLogout() {
    // NOTE: Phase 11 adds real session/token clearing here before
    // navigating away. For now this just returns to Login.
    router.replace('/(auth)/login');
  }

  return (
    <SafeAreaView edges={['top']} style={[styles.flex, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <ThemedText type="title" style={styles.title}>
          My Profile
        </ThemedText>

        <View style={styles.avatarSection}>
          <View style={[styles.avatar, { backgroundColor: colors.tint }]}>
            <ThemedText style={styles.avatarText}>{getInitials(mockDriver.fullName)}</ThemedText>
          </View>
          <ThemedText type="subtitle" style={styles.name}>
            {mockDriver.fullName}
          </ThemedText>
        </View>

        <View style={[styles.card, cardBorder]}>
          <ProfileRow icon="envelope.fill" label={mockDriver.email} />
          <ProfileRow icon="phone.fill" label={mockDriver.phone} />
          <ProfileRow icon="car.fill" label={mockDriver.vehicleReg} showDivider={false} />
        </View>

        <View style={[styles.card, cardBorder]}>
          <ProfileRow
            icon="figure.roll"
            label="Accessibility Settings"
            showDivider={false}
            onPress={() => router.push('/accessibility-settings')}
          />
        </View>

        <View style={styles.logoutSpacing}>
          <PrimaryButton label="Log Out" onPress={handleLogout} />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 40 },
  title: { fontSize: 24, marginBottom: 20 },
  avatarSection: { alignItems: 'center', marginBottom: 24 },
  avatar: {
    width: 88,
    height: 88,
    borderRadius: 44,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  avatarText: { color: '#fff', fontSize: 30, fontWeight: '800' },
  name: { fontSize: 22 },
  card: {
    borderWidth: 1,
    borderRadius: 16,
    paddingHorizontal: 18,
    marginBottom: 16,
  },
  logoutSpacing: { marginTop: 12 },
});
