import { router } from 'expo-router';
import { Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { QuickActionCard } from '@/components/quick-action-card';
import { ReadAloudButton } from '@/components/read-aloud-button';
import { ThemedText } from '@/components/themed-text';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { Colors } from '@/constants/theme';
import { mockDriver, mockNotifications } from '@/constants/mock-data';
import { useSession } from '@/contexts/session-context';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useThemeStyles } from '@/hooks/use-theme-styles';
import { useNowTick } from '@/hooks/use-now-tick';
import { formatClockTime, formatDuration } from '@/utils/format-duration';
import { formatCurrency } from '@/utils/session-billing';

const ACTIVE_GREEN = '#12B76A';
const PENDING_AMBER = '#F79009';
const EXIT_BLUE = '#2E90FA';

export default function HomeScreen() {
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'light'];
  const { activeSession, pendingReservation, pendingExit } = useSession();
  const { cardBorder } = useThemeStyles();

  // Keeps the duration line fresh while this screen is open.
  useNowTick(30000);

  // First name only, for a friendlier greeting.
  const firstName = mockDriver.fullName.split(' ')[0];
  const unreadCount = mockNotifications.filter((n) => !n.isRead).length;

  const hasAnyStatus = !!(activeSession || pendingReservation || pendingExit);

  function handleStatusPress() {
    if (pendingExit) router.push('/(tabs)/my-ticket');
    else if (activeSession) router.push('/active-session');
    else if (pendingReservation) router.push('/(tabs)/my-ticket');
  }

  const spokenSummary = pendingExit
    ? `Session ended for bay ${pendingExit.bayLabel}. Amount due: ${formatCurrency(pendingExit.fee)}. Get your exit QR code to leave.`
    : activeSession
      ? `Session active in bay ${activeSession.bayLabel}, entered at ${formatClockTime(activeSession.entryTimestamp)}.`
      : pendingReservation
        ? `Reservation pending for bay ${pendingReservation.bayLabel}. Scan your QR code at the gate to begin.`
        : `Hi ${firstName}. No active parking session right now.`;

  return (
    <SafeAreaView edges={['top']} style={[styles.flex, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <View style={styles.headerText}>
            <ThemedText type="title" style={styles.greeting}>
              Hi, {firstName} 👋
            </ThemedText>
            <ThemedText style={styles.subtitle}>Here&apos;s your parking overview</ThemedText>
          </View>
          <View style={styles.headerActions}>
            <ReadAloudButton text={spokenSummary} />
            <Pressable
              onPress={() => router.push('/notifications')}
              accessibilityRole="button"
              accessibilityLabel={
                unreadCount > 0 ? `Notifications, ${unreadCount} unread` : 'Notifications'
              }
              hitSlop={10}
              style={styles.bellButton}>
              <IconSymbol name="bell.fill" size={22} color={colors.text} />
              {unreadCount > 0 && (
                <View style={[styles.bellBadge, { backgroundColor: colors.tint }]}>
                  <ThemedText style={styles.bellBadgeText}>{unreadCount}</ThemedText>
                </View>
              )}
            </Pressable>
          </View>
        </View>

        <Pressable
          onPress={hasAnyStatus ? handleStatusPress : undefined}
          accessibilityRole={hasAnyStatus ? 'button' : undefined}
          accessibilityLabel={hasAnyStatus ? spokenSummary : undefined}
          style={({ pressed }) => [
            styles.statusCard,
            cardBorder,
            hasAnyStatus && pressed ? { opacity: 0.8 } : undefined,
          ]}>
          {pendingExit ? (
            <>
              <View style={styles.statusHeaderRow}>
                <View style={[styles.dot, { backgroundColor: EXIT_BLUE }]} />
                <ThemedText style={styles.statusLabel}>Ready to Exit</ThemedText>
              </View>
              <ThemedText type="subtitle" style={styles.statusValue}>
                {pendingExit.bayLabel}
              </ThemedText>
              <ThemedText style={styles.statusMeta}>
                Amount due {formatCurrency(pendingExit.fee)} · Tap to get exit QR
              </ThemedText>
            </>
          ) : activeSession ? (
            <>
              <View style={styles.statusHeaderRow}>
                <View style={[styles.dot, { backgroundColor: ACTIVE_GREEN }]} />
                <ThemedText style={styles.statusLabel}>Session Active</ThemedText>
              </View>
              <ThemedText type="subtitle" style={styles.statusValue}>
                {activeSession.bayLabel}
              </ThemedText>
              <ThemedText style={styles.statusMeta}>
                Entered at {formatClockTime(activeSession.entryTimestamp)} ·{' '}
                {formatDuration(Date.now() - activeSession.entryTimestamp)} · Tap for details
              </ThemedText>
            </>
          ) : pendingReservation ? (
            <>
              <View style={styles.statusHeaderRow}>
                <View style={[styles.dot, { backgroundColor: PENDING_AMBER }]} />
                <ThemedText style={styles.statusLabel}>Reservation Pending</ThemedText>
              </View>
              <ThemedText type="subtitle" style={styles.statusValue}>
                {pendingReservation.bayLabel}
              </ThemedText>
              <ThemedText style={styles.statusMeta}>
                Scan your QR at the gate to begin · Tap to view ticket
              </ThemedText>
            </>
          ) : (
            <>
              <ThemedText style={styles.statusLabel}>Parking Status</ThemedText>
              <ThemedText type="subtitle" style={styles.statusValue}>
                No Active Session
              </ThemedText>
              <ThemedText style={styles.statusMeta}>
                Find a bay to start parking.
              </ThemedText>
            </>
          )}
        </Pressable>

        <ThemedText style={styles.sectionTitle}>Quick Actions</ThemedText>
        <View style={styles.actionsGrid}>
          <View style={styles.gridItem}>
            <QuickActionCard
              label="Find Parking"
              icon="mappin.circle.fill"
              onPress={() => router.push('/(tabs)/find-parking')}
            />
          </View>
          <View style={styles.gridItem}>
            <QuickActionCard
              label="My Ticket"
              icon="qrcode"
              onPress={() => router.push('/(tabs)/my-ticket')}
            />
          </View>
          <View style={styles.gridItem}>
            <QuickActionCard
              label="History"
              icon="clock.arrow.circlepath"
              onPress={() => router.push('/history')}
            />
          </View>
          <View style={styles.gridItem}>
            <QuickActionCard
              label="Profile"
              icon="person.fill"
              onPress={() => router.push('/(tabs)/profile')}
            />
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 40 },
  header: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 24 },
  headerText: { flex: 1, marginRight: 12 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  greeting: { fontSize: 26, marginBottom: 4 },
  subtitle: { opacity: 0.7, fontSize: 15 },
  bellButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(128,128,128,0.12)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  bellBadge: {
    position: 'absolute',
    top: -2,
    right: -2,
    minWidth: 20,
    height: 20,
    borderRadius: 10,
    paddingHorizontal: 5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bellBadgeText: { color: '#fff', fontWeight: '700', fontSize: 11 },
  statusCard: {
    borderWidth: 1,
    borderRadius: 16,
    padding: 20,
    marginBottom: 28,
  },
  statusHeaderRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 },
  dot: { width: 8, height: 8, borderRadius: 4 },
  statusLabel: { fontSize: 14, opacity: 0.7, marginBottom: 4 },
  statusValue: { fontSize: 20, marginBottom: 4 },
  statusMeta: { fontSize: 14, opacity: 0.6 },
  sectionTitle: { fontSize: 16, fontWeight: '700', marginBottom: 12 },
  actionsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  gridItem: { width: '47%' },
});
