import { router } from 'expo-router';
import { ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { InfoRow } from '@/components/info-row';
import { PrimaryButton } from '@/components/primary-button';
import { ScreenHeader } from '@/components/screen-header';
import { ThemedText } from '@/components/themed-text';
import { Colors } from '@/constants/theme';
import { useSession } from '@/contexts/session-context';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useThemeStyles } from '@/hooks/use-theme-styles';
import { formatDuration } from '@/utils/format-duration';
import { formatCurrency } from '@/utils/session-billing';

export default function SessionSummaryScreen() {
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'light'];
  const { pendingExit } = useSession();
  const { cardBorder } = useThemeStyles();

  // Reached with nothing to summarize (e.g. a stale deep link) — send
  // the driver somewhere useful rather than showing an empty screen.
  if (!pendingExit) {
    return (
      <SafeAreaView edges={['top']} style={[styles.flex, { backgroundColor: colors.background }]}>
        <ScreenHeader title="Session Summary" />
        <View style={styles.emptyState}>
          <ThemedText>No session to summarize right now.</ThemedText>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView edges={['top']} style={[styles.flex, { backgroundColor: colors.background }]}>
      <ScreenHeader title="Session Summary" />

      <ScrollView contentContainerStyle={styles.content}>
        <ThemedText type="title" style={styles.heading}>
          Session Ended
        </ThemedText>
        <ThemedText style={styles.subheading}>Here&apos;s what you owe for this session.</ThemedText>

        <View style={[styles.card, cardBorder]}>
          <InfoRow icon="mappin.circle.fill" label="Parking Bay" value={pendingExit.bayLabel} />
          <InfoRow
            icon="arrow.triangle.2.circlepath"
            label="Time Parked"
            value={formatDuration(pendingExit.durationMs)}
          />
          <InfoRow
            icon="checkmark.circle.fill"
            label="Amount Due"
            value={formatCurrency(pendingExit.fee)}
            showDivider={false}
          />
        </View>

        <View style={styles.buttonWrap}>
          <PrimaryButton label="Get Exit QR Code" onPress={() => router.push('/(tabs)/my-ticket')} />
          <ThemedText style={styles.note}>
            Present this at the payment toll or boom gate on your way out.
          </ThemedText>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
  content: { padding: 20, paddingBottom: 40 },
  heading: { fontSize: 24, marginBottom: 4 },
  subheading: { opacity: 0.7, marginBottom: 24 },
  card: {
    borderWidth: 1,
    borderRadius: 16,
    paddingHorizontal: 18,
    marginBottom: 28,
  },
  buttonWrap: { gap: 10, alignItems: 'center' },
  note: { fontSize: 12, opacity: 0.6, textAlign: 'center', paddingHorizontal: 20 },
});
