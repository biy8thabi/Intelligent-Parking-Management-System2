import { router } from 'expo-router';
import { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { FormTextField } from '@/components/form-text-field';
import { PrimaryButton } from '@/components/primary-button';
import { ThemedText } from '@/components/themed-text';
import { Colors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { isValidEmail } from '@/utils/validation';

type FormErrors = {
  email?: string;
  password?: string;
};

export default function LoginScreen() {
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'light'];
  const tint = colors.tint;

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<FormErrors>({});

  function handleLogin() {
    const nextErrors: FormErrors = {};
    if (!email.trim()) nextErrors.email = 'Email address is required.';
    else if (!isValidEmail(email)) nextErrors.email = 'Enter a valid email address.';
    if (!password) nextErrors.password = 'Password is required.';

    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    // NOTE: no backend call yet — Phase 11 replaces this with a real
    // POST to the Node/Express auth endpoint. For now, a valid form
    // just proceeds into the app.
    router.replace('/(tabs)');
  }

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <SafeAreaView style={[styles.flex, { backgroundColor: colors.background }]}>
        <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
          <View style={styles.header}>
            <View style={[styles.logoBox, { borderColor: tint }]}>
              <ThemedText style={[styles.logoText, { color: tint }]}>IPMS</ThemedText>
            </View>
            <View style={styles.headerText}>
              <ThemedText type="title" style={styles.title}>
                IPMS Portal
              </ThemedText>
              <ThemedText style={styles.subtitle}>Log in to manage your parking</ThemedText>
            </View>
          </View>

          <FormTextField
            label="Email Address"
            placeholder="name@example.com"
            value={email}
            onChangeText={setEmail}
            error={errors.email}
            autoCapitalize="none"
            autoCorrect={false}
            keyboardType="email-address"
            textContentType="emailAddress"
          />

          <FormTextField
            label="Password"
            placeholder="Enter your password"
            value={password}
            onChangeText={setPassword}
            error={errors.password}
            isPassword
            textContentType="password"
          />

          <View style={styles.buttonSpacing}>
            <PrimaryButton label="Log In" onPress={handleLogin} />
          </View>

          <View style={styles.footer}>
            <ThemedText>{"Don't have an account? "}</ThemedText>
            <ThemedText
              style={[styles.link, { color: tint }]}
              accessibilityRole="link"
              onPress={() => router.push('/(auth)/register')}>
              Register
            </ThemedText>
          </View>
        </ScrollView>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  scrollContent: { flexGrow: 1, justifyContent: 'center', padding: 24 },
  header: { flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 32 },
  logoBox: {
    width: 56,
    height: 56,
    borderRadius: 14,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoText: { fontWeight: '800', fontSize: 13 },
  headerText: { flex: 1 },
  title: { fontSize: 24, marginBottom: 2 },
  subtitle: { opacity: 0.7, fontSize: 15 },
  buttonSpacing: { marginTop: 8 },
  footer: { flexDirection: 'row', justifyContent: 'center', marginTop: 24 },
  link: { fontWeight: '700' },
});
