import { router } from 'expo-router';
import { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { FormTextField } from '@/components/form-text-field';
import { PrimaryButton } from '@/components/primary-button';
import { ScreenHeader } from '@/components/screen-header';
import { ThemedText } from '@/components/themed-text';
import { Colors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { isValidEmail, isValidPhone, isValidVehicleReg } from '@/utils/validation';

type FormErrors = {
  fullName?: string;
  email?: string;
  phone?: string;
  vehicleReg?: string;
  password?: string;
};

export default function RegisterScreen() {
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'light'];

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  // NOTE: vehicleReg is collected here but the `users` table in the shared
  // schema doesn't have a column for it yet — flagged with the team.
  // Kept in local form state until the backend supports it.
  const [vehicleReg, setVehicleReg] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<FormErrors>({});

  function handleRegister() {
    const nextErrors: FormErrors = {};
    if (!fullName.trim()) nextErrors.fullName = 'Full name is required.';
    if (!email.trim()) nextErrors.email = 'Email address is required.';
    else if (!isValidEmail(email)) nextErrors.email = 'Enter a valid email address.';
    if (!phone.trim()) nextErrors.phone = 'Phone number is required.';
    else if (!isValidPhone(phone)) nextErrors.phone = 'Enter a valid phone number.';
    if (!vehicleReg.trim()) nextErrors.vehicleReg = 'Vehicle registration number is required.';
    else if (!isValidVehicleReg(vehicleReg)) nextErrors.vehicleReg = 'Enter a valid registration number.';
    if (!password) nextErrors.password = 'Password is required.';
    else if (password.length < 6) nextErrors.password = 'Password must be at least 6 characters.';

    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    // NOTE: no backend call yet — Phase 11 wires this to a real
    // POST /register endpoint. For now, a valid form just returns to Login.
    router.replace('/(auth)/login');
  }

  return (
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <SafeAreaView edges={['top']} style={[styles.flex, { backgroundColor: colors.background }]}>
        <ScreenHeader title="Create Account" />

        <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
          <FormTextField
            label="Full Name"
            placeholder="John Doe"
            value={fullName}
            onChangeText={setFullName}
            error={errors.fullName}
            autoCapitalize="words"
            textContentType="name"
          />

          <FormTextField
            label="Email Address"
            placeholder="name@example.com"
            value={email}
            onChangeText={setEmail}
            error={errors.email}
            autoCapitalize="none"
            autoCorrect={false}
            keyboardType="email-address"
            textContentType="emailAddress"
          />

          <FormTextField
            label="Phone Number"
            placeholder="+27 82 123 4567"
            value={phone}
            onChangeText={setPhone}
            error={errors.phone}
            keyboardType="phone-pad"
            textContentType="telephoneNumber"
          />

          <FormTextField
            label="Vehicle Registration Number"
            placeholder="e.g. CA 123-456"
            value={vehicleReg}
            onChangeText={setVehicleReg}
            error={errors.vehicleReg}
            autoCapitalize="characters"
          />

          <FormTextField
            label="Password"
            placeholder="Choose secure password"
            value={password}
            onChangeText={setPassword}
            error={errors.password}
            isPassword
            textContentType="newPassword"
          />

          <View style={styles.buttonSpacing}>
            <PrimaryButton label="Register" onPress={handleRegister} />
          </View>

          <View style={styles.footer}>
            <ThemedText>Already have an account? </ThemedText>
            <ThemedText
              style={[styles.link, { color: colors.tint }]}
              accessibilityRole="link"
              onPress={() => router.back()}>
              Log In
            </ThemedText>
          </View>
        </ScrollView>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  scrollContent: { padding: 24, paddingTop: 8 },
  buttonSpacing: { marginTop: 8 },
  footer: { flexDirection: 'row', justifyContent: 'center', marginTop: 20, marginBottom: 24 },
  link: { fontWeight: '700' },
});
