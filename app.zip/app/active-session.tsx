import { router } from 'expo-router';
import { ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { InfoRow } from '@/components/info-row';
import { PrimaryButton } from '@/components/primary-button';
import { ReadAloudButton } from '@/components/read-aloud-button';
import { ScreenHeader } from '@/components/screen-header';
import { ThemedText } from '@/components/themed-text';
import { Colors } from '@/constants/theme';
import { useSession } from '@/contexts/session-context';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useThemeStyles } from '@/hooks/use-theme-styles';
import { useNowTick } from '@/hooks/use-now-tick';
import { formatClockTime, formatDuration } from '@/utils/format-duration';

const ACTIVE_GREEN = '#12B76A';

export default function ActiveSessionScreen() {
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'light'];
  const { activeSession, endSession } = useSession();
  const { cardBorder } = useThemeStyles();

  // Keeps the duration row fresh while this screen is open.
  useNowTick(15000);

  // In the rare case this screen is reached with no active session
  // (e.g. a stale deep link, or the app restarted and lost in-memory
  // state — Phase 11's real session would be fetched from the backend
  // instead), show a simple fallback rather than crash.
  if (!activeSession) {
    return (
      <SafeAreaView edges={['top']} style={[styles.flex, { backgroundColor: colors.background }]}>
        <ScreenHeader title="Active Parking Session" />
        <View style={styles.emptyState}>
          <ThemedText>No active session right now.</ThemedText>
        </View>
      </SafeAreaView>
    );
  }

  const duration = formatDuration(Date.now() - activeSession.entryTimestamp);
  const entryTime = formatClockTime(activeSession.entryTimestamp);

  function handleEndSession() {
    endSession();
    router.push('/session-summary');
  }

  const spokenSummary = `You are parked in bay ${activeSession.bayLabel}, on ${activeSession.floorLabel}. You entered at ${entryTime}. Your session has been active for ${duration}.`;

  return (
    <SafeAreaView edges={['top']} style={[styles.flex, { backgroundColor: colors.background }]}>
      <ScreenHeader title="Active Parking Session" />

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.topRow}>
          <View style={[styles.statusPill, { backgroundColor: `${ACTIVE_GREEN}1A` }]}>
            <View style={[styles.dot, { backgroundColor: ACTIVE_GREEN }]} />
            <ThemedText style={[styles.statusPillText, { color: ACTIVE_GREEN }]}>Session Active</ThemedText>
          </View>
          <ReadAloudButton text={spokenSummary} />
        </View>

        <View style={[styles.card, cardBorder]}>
          <InfoRow icon="square.stack.3d.up.fill" label="Floor" value={activeSession.floorLabel} />
          <InfoRow icon="mappin.circle.fill" label="Parking Bay" value={activeSession.bayLabel} />
          <InfoRow icon="clock.fill" label="Entry Time" value={entryTime} />
          <InfoRow icon="arrow.triangle.2.circlepath" label="Duration" value={duration} />
          <InfoRow
            icon="checkmark.circle.fill"
            label="Status"
            value="Active"
            valueColor={ACTIVE_GREEN}
            showDivider={false}
          />
        </View>

        <View style={styles.endButtonWrap}>
          <PrimaryButton label="End Session" onPress={handleEndSession} variant="danger" />
          <ThemedText style={styles.endNote}>
            You&apos;ll get a summary and an exit QR code to scan at the boom gate on your way out.
          </ThemedText>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  content: { padding: 20, paddingBottom: 40 },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
  topRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 24,
  },
  dot: { width: 8, height: 8, borderRadius: 4 },
  statusPillText: { fontWeight: '700', fontSize: 14 },
  card: {
    borderWidth: 1,
    borderRadius: 16,
    paddingHorizontal: 18,
  },
  endButtonWrap: { marginTop: 28, gap: 10, alignItems: 'center' },
  endNote: { fontSize: 12, opacity: 0.6, textAlign: 'center', paddingHorizontal: 16 },
});
