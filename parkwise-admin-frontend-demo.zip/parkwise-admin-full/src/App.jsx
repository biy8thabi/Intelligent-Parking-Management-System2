import {Routes,Route,Navigate} from "react-router-dom";
import {useEffect, useState} from "react";
import Login from "./pages/Login";
import Layout from "./components/Layout";
import Dashboard from "./pages/Dashboard";
import CrudPage from "./pages/CrudPage";
import Settings from "./pages/Settings";
import FeeCalculator from "./pages/FeeCalculator";

const names=["Parking Lots","Parking Slots","Drivers","Vehicles","Bookings","Payments","QR Tickets","Admin Profile"];
export default function App(){
  const [ok,setOk]=useState(()=>localStorage.getItem("pw_admin")==="1");
  const [theme,setTheme]=useState(()=>localStorage.getItem("pw_theme")||"dark");
  useEffect(()=>{document.documentElement.dataset.theme=theme;localStorage.setItem("pw_theme",theme)},[theme]);
  if(!ok)return <Login onLogin={()=>{localStorage.setItem("pw_admin","1");setOk(true)}}/>;
  return <Routes><Route path="/" element={<Layout theme={theme} onThemeChange={setTheme} onLogout={()=>{localStorage.removeItem("pw_admin");setOk(false)}}/>}>
    <Route index element={<Dashboard/>}/>
    {names.map(n=><Route key={n} path={n.toLowerCase().replaceAll(" ","-")} element={<CrudPage title={n}/>}/>)}
    <Route path="settings" element={<Settings theme={theme} onThemeChange={setTheme}/>}/>
    <Route path="fee-calculator" element={<FeeCalculator/>}/>
  </Route><Route path="*" element={<Navigate to="/"/>}/></Routes>
}
