# ParkWise Admin Portal — Frontend Demo

React + Vite admin portal for the ParkWise Intelligent Parking Management System.

## Run locally
1. Install Node.js LTS.
2. Open this folder in VS Code (the folder containing `package.json`).
3. In the VS Code terminal run `npm.cmd install` and then `npm.cmd run dev`.
4. Open the local URL printed by Vite.

## Included frontend-only functionality
- Admin demo sign-in form (not secure authentication; any valid email and non-empty password work).
- Dashboard overview with sample metrics.
- Search, status filters, add/edit/delete and reset for demo management tables.
- Local browser storage for table edits, theme and preferences.
- Light/dark theme.
- Parking fee calculator with configurable sample hourly/daily rates and grace period.
- Printable sample ticket preview.
- Responsive layout for smaller screens.

## Important demo limitations
All sample records and preferences are stored in this browser only. This is not a live parking system. Login is not secure; do not use real credentials. The decorative ticket graphic is not a real QR code. Database CRUD, secure authentication, live occupancy, real ticket validation, email notifications and payment processing require the team backend/API. Never place the Supabase service-role key in this frontend.
