import { StyleSheet, View } from 'react-native';

import { ThemedText } from '@/components/themed-text';
import type { MockHistoryEntry } from '@/constants/mock-data';
import { useThemeStyles } from '@/hooks/use-theme-styles';

const COMPLETED_GREEN = '#12B76A';

type HistorySessionCardProps = {
  entry: MockHistoryEntry;
};

export function HistorySessionCard({ entry }: HistorySessionCardProps) {
  const { cardBorder } = useThemeStyles();

  return (
    <View style={[styles.card, cardBorder]}>
      <View style={styles.topRow}>
        <ThemedText style={styles.date}>{entry.date}</ThemedText>
        <View style={styles.pill}>
          <ThemedText style={styles.pillText}>Completed</ThemedText>
        </View>
      </View>

      <ThemedText style={styles.line}>
        Entry: {entry.entryTime} · Exit: {entry.exitTime}
      </ThemedText>
      <ThemedText style={styles.line}>Duration: {entry.duration}</ThemedText>
      <ThemedText style={styles.line}>Bay: {entry.bayLabel}</ThemedText>
      <ThemedText style={styles.fee}>Fee: {entry.fee}</ThemedText>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderWidth: 1,
    borderRadius: 14,
    padding: 18,
    marginBottom: 14,
  },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  date: { fontSize: 17, fontWeight: '700' },
  pill: {
    backgroundColor: `${COMPLETED_GREEN}1A`,
    borderRadius: 20,
    paddingVertical: 4,
    paddingHorizontal: 12,
  },
  pillText: { color: COMPLETED_GREEN, fontWeight: '700', fontSize: 12 },
  line: { fontSize: 14, opacity: 0.75, marginBottom: 4 },
  fee: { fontSize: 15, fontWeight: '700', marginTop: 2 },
});
