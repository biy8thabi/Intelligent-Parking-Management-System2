import { StyleSheet, View } from 'react-native';

import { ThemedText } from '@/components/themed-text';
import { IconSymbol, type IconSymbolName } from '@/components/ui/icon-symbol';
import { Colors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useThemeStyles } from '@/hooks/use-theme-styles';

type InfoRowProps = {
  icon: IconSymbolName;
  label: string;
  value: string;
  valueColor?: string;
  showDivider?: boolean;
};

export function InfoRow({ icon, label, value, valueColor, showDivider = true }: InfoRowProps) {
  const colorScheme = useColorScheme();
  const tint = Colors[colorScheme ?? 'light'].tint;
  const { borderColor } = useThemeStyles();

  return (
    <View style={[styles.row, showDivider ? [styles.rowDivider, { borderBottomColor: borderColor }] : undefined]}>
      <IconSymbol name={icon} size={20} color={tint} style={styles.icon} />
      <View style={styles.textBlock}>
        <ThemedText style={styles.label}>{label}</ThemedText>
        <ThemedText style={[styles.value, valueColor ? { color: valueColor } : undefined]}>
          {value}
        </ThemedText>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 16 },
  rowDivider: { borderBottomWidth: 1 },
  icon: { marginRight: 14 },
  textBlock: { flex: 1 },
  label: { fontSize: 14, opacity: 0.6, marginBottom: 2 },
  value: { fontSize: 17, fontWeight: '700' },
});
