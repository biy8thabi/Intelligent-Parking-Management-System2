import { StyleSheet, View } from 'react-native';

import { ThemedText } from '@/components/themed-text';
import { Colors } from '@/constants/theme';
import type { MockNotification } from '@/constants/mock-data';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useThemeStyles } from '@/hooks/use-theme-styles';

type NotificationCardProps = {
  notification: MockNotification;
};

export function NotificationCard({ notification }: NotificationCardProps) {
  const colorScheme = useColorScheme();
  const tint = Colors[colorScheme ?? 'light'].tint;
  const { borderColor } = useThemeStyles();
  const { title, message, timeAgo, isRead } = notification;

  return (
    <View
      style={[
        styles.card,
        { borderBottomColor: borderColor },
        !isRead && { backgroundColor: `${tint}12`, borderLeftColor: tint, borderLeftWidth: 4 },
      ]}>
      <View style={styles.topRow}>
        <ThemedText style={styles.title}>{title}</ThemedText>
        {!isRead && <View style={[styles.dot, { backgroundColor: tint }]} />}
      </View>
      <ThemedText style={styles.message}>{message}</ThemedText>
      <ThemedText style={[styles.timeAgo, !isRead ? { color: tint } : undefined]}>{timeAgo}</ThemedText>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderBottomWidth: 1,
    paddingVertical: 16,
    paddingHorizontal: 20,
  },
  topRow: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  title: { fontSize: 16, fontWeight: '700', flex: 1, marginRight: 8 },
  dot: { width: 8, height: 8, borderRadius: 4, marginTop: 6 },
  message: { fontSize: 14, opacity: 0.75, lineHeight: 20, marginTop: 4 },
  timeAgo: { fontSize: 13, opacity: 0.6, marginTop: 8 },
});
