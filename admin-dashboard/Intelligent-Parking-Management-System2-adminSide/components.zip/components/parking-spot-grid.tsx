import { Pressable, StyleSheet, View } from 'react-native';

import { ThemedText } from '@/components/themed-text';
import { IconSymbol } from '@/components/ui/icon-symbol';
import type { ParkingBay } from '@/constants/mall-data';
import { Colors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useThemeStyles } from '@/hooks/use-theme-styles';

const STATUS_COLORS = {
  available: '#12B76A',
  occupied: '#F04438',
  disabled: '#F79009',
};

type ParkingSpotGridProps = {
  bays: ParkingBay[];
  selectedBayId: string | null;
  yourBayId: string | null;
  /** True when yourBayId is a reservation awaiting the gate scan, not yet an active session. */
  yourBayPending?: boolean;
  onSelect: (bayId: string) => void;
};

export function ParkingSpotGrid({
  bays,
  selectedBayId,
  yourBayId,
  yourBayPending = false,
  onSelect,
}: ParkingSpotGridProps) {
  const colorScheme = useColorScheme();
  const tint = Colors[colorScheme ?? 'light'].tint;
  const { borderColor: themeBorder, surfaceColor } = useThemeStyles();

  return (
    <View style={styles.grid}>
      {bays.map((bay) => {
        const isYourBay = bay.id === yourBayId;
        const isSelected = bay.id === selectedBayId;
        const isTappable = !isYourBay && bay.status === 'available';

        let backgroundColor = surfaceColor;
        let borderColor = themeBorder;
        let textColor: string = STATUS_COLORS.available;

        if (isYourBay) {
          backgroundColor = tint;
          borderColor = tint;
        } else if (isSelected) {
          backgroundColor = tint;
          borderColor = tint;
        } else if (bay.status === 'occupied') {
          backgroundColor = `${STATUS_COLORS.occupied}14`;
          borderColor = `${STATUS_COLORS.occupied}55`;
          textColor = STATUS_COLORS.occupied;
        } else if (bay.status === 'disabled') {
          backgroundColor = `${STATUS_COLORS.disabled}14`;
          borderColor = `${STATUS_COLORS.disabled}55`;
          textColor = STATUS_COLORS.disabled;
        } else {
          backgroundColor = `${STATUS_COLORS.available}14`;
          borderColor = `${STATUS_COLORS.available}55`;
          textColor = STATUS_COLORS.available;
        }

        return (
          <Pressable
            key={bay.id}
            disabled={!isTappable}
            onPress={() => onSelect(bay.id)}
            accessibilityRole={isTappable ? 'button' : undefined}
            accessibilityLabel={
              isYourBay
                ? `${bay.spotNumber}, ${yourBayPending ? 'your reserved spot, awaiting scan' : 'your parked spot'}`
                : `${bay.spotNumber}, ${bay.status}${isSelected ? ', selected' : ''}`
            }
            style={[styles.cell, { backgroundColor, borderColor }]}>
            {isYourBay ? (
              <IconSymbol name={yourBayPending ? 'qrcode' : 'car.fill'} size={18} color="#fff" />
            ) : bay.status === 'disabled' ? (
              <IconSymbol name="figure.roll" size={16} color={textColor} />
            ) : null}
            <ThemedText
              style={[
                styles.cellText,
                { color: isYourBay || isSelected ? '#fff' : textColor },
              ]}>
              {isYourBay ? (yourBayPending ? 'Reserved' : 'Parked') : bay.spotNumber}
            </ThemedText>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  cell: {
    width: '22%',
    aspectRatio: 1,
    borderWidth: 1.5,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 2,
  },
  cellText: { fontSize: 11, fontWeight: '700' },
});
