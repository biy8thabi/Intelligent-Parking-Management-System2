import { Pressable, StyleSheet, View } from 'react-native';

import { ThemedText } from '@/components/themed-text';
import { IconSymbol, type IconSymbolName } from '@/components/ui/icon-symbol';
import { Colors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useThemeStyles } from '@/hooks/use-theme-styles';

type ProfileRowProps = {
  icon: IconSymbolName;
  label: string;
  showDivider?: boolean;
  onPress?: () => void;
};

export function ProfileRow({ icon, label, showDivider = true, onPress }: ProfileRowProps) {
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'light'];
  const { borderColor } = useThemeStyles();

  const content = (
    <View style={[styles.row, showDivider ? [styles.rowDivider, { borderBottomColor: borderColor }] : undefined]}>
      <IconSymbol name={icon} size={20} color={colors.tint} style={styles.icon} />
      <ThemedText style={styles.label}>{label}</ThemedText>
      {onPress && <IconSymbol name="chevron.right" size={18} color={colors.icon} />}
    </View>
  );

  if (!onPress) return content;

  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={({ pressed }) => (pressed ? { opacity: 0.7 } : undefined)}>
      {content}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 16 },
  rowDivider: { borderBottomWidth: 1 },
  icon: { marginRight: 14 },
  label: { flex: 1, fontSize: 16, fontWeight: '500' },
});
