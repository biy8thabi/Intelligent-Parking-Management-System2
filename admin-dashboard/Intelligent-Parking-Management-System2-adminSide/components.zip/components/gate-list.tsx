import { StyleSheet, View } from 'react-native';

import { ThemedText } from '@/components/themed-text';
import { IconSymbol, type IconSymbolName } from '@/components/ui/icon-symbol';
import type { Gate, GateKind } from '@/constants/mall-data';
import { useThemeStyles } from '@/hooks/use-theme-styles';

const KIND_META: Record<GateKind, { label: string; icon: IconSymbolName }> = {
  entry: { label: 'Entry only', icon: 'arrow.right.to.line' },
  exit: { label: 'Exit only', icon: 'arrow.right.square' },
  'entry-exit': { label: 'Entry & Exit', icon: 'arrow.left.arrow.right' },
};

type GateListProps = {
  gates: Gate[];
};

export function GateList({ gates }: GateListProps) {
  const { cardBorder } = useThemeStyles();

  return (
    <View style={styles.column}>
      {gates.map((gate) => {
        const meta = KIND_META[gate.kind];
        return (
          <View key={gate.id} style={[styles.card, cardBorder]}>
            <IconSymbol name={meta.icon} size={20} color="#667085" />
            <View style={styles.textBlock}>
              <ThemedText style={styles.gateLabel}>
                {gate.label} · {meta.label}
              </ThemedText>
              <ThemedText style={styles.gateNote}>Near {gate.nearStore}</ThemedText>
              {gate.note && (
                <View style={styles.factRow}>
                  <IconSymbol name="figure.roll" size={13} color="#2E90FA" />
                  <ThemedText style={styles.factText}>{gate.note}</ThemedText>
                </View>
              )}
            </View>
          </View>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  column: { gap: 10 },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderWidth: 1,
    borderRadius: 12,
    padding: 14,
  },
  textBlock: { flex: 1 },
  gateLabel: { fontSize: 14, fontWeight: '700' },
  gateNote: { fontSize: 12, opacity: 0.6, marginTop: 2 },
  factRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 5, marginTop: 6 },
  factText: { flex: 1, fontSize: 11, color: '#2E90FA', lineHeight: 15 },
});
