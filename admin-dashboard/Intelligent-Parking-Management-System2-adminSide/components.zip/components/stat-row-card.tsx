import { StyleSheet, View } from 'react-native';

import { ThemedText } from '@/components/themed-text';
import { IconSymbol, type IconSymbolName } from '@/components/ui/icon-symbol';
import { useThemeStyles } from '@/hooks/use-theme-styles';

type StatRowCardProps = {
  label: string;
  note: string;
  count: number;
  icon: IconSymbolName;
  color: string;
};

export function StatRowCard({ label, note, count, icon, color }: StatRowCardProps) {
  const { cardBorder } = useThemeStyles();

  return (
    <View style={[styles.card, cardBorder]}>
      <View style={styles.textBlock}>
        <ThemedText style={styles.label}>{label}</ThemedText>
        <View style={styles.noteRow}>
          <IconSymbol name={icon} size={16} color={color} />
          <ThemedText style={[styles.note, { color }]}>{note}</ThemedText>
        </View>
      </View>
      <ThemedText style={[styles.count, { color }]}>{count}</ThemedText>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderRadius: 14,
    padding: 18,
    marginBottom: 14,
  },
  textBlock: { flex: 1 },
  label: { fontSize: 17, fontWeight: '700', marginBottom: 6 },
  noteRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  note: { fontSize: 14, fontWeight: '500' },
  count: { fontSize: 32, fontWeight: '800', marginLeft: 12 },
});
