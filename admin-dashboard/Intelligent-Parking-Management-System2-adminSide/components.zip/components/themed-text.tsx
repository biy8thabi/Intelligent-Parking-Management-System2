import { StyleSheet, Text, type TextProps, type TextStyle } from 'react-native';

import { useAccessibility } from '@/contexts/accessibility-context';
import { useThemeColor } from '@/hooks/use-theme-color';

export type ThemedTextProps = TextProps & {
  lightColor?: string;
  darkColor?: string;
  type?: 'default' | 'title' | 'defaultSemiBold' | 'subtitle' | 'link';
};

export function ThemedText({
  style,
  lightColor,
  darkColor,
  type = 'default',
  ...rest
}: ThemedTextProps) {
  const color = useThemeColor({ light: lightColor, dark: darkColor }, 'text');
  const { fontScaleMultiplier, highContrast } = useAccessibility();

  // Flattening here means every screen's existing fontSize/lineHeight/
  // opacity values (however they were set — via `type`, or an inline
  // style prop) get scaled and contrast-boosted uniformly, without
  // needing to touch each of the ~20 files that render text.
  const flattened = StyleSheet.flatten([
    type === 'default' ? styles.default : undefined,
    type === 'title' ? styles.title : undefined,
    type === 'defaultSemiBold' ? styles.defaultSemiBold : undefined,
    type === 'subtitle' ? styles.subtitle : undefined,
    type === 'link' ? styles.link : undefined,
    style,
  ]) as TextStyle;

  const scaleOverride: TextStyle = {};
  if (typeof flattened.fontSize === 'number') {
    scaleOverride.fontSize = flattened.fontSize * fontScaleMultiplier;
  }
  if (typeof flattened.lineHeight === 'number') {
    scaleOverride.lineHeight = flattened.lineHeight * fontScaleMultiplier;
  }

  return (
    <Text
      style={[
        { color },
        flattened,
        scaleOverride,
        // Most "muted" text in this app is a ThemedText with a lower
        // opacity baked into its style (e.g. subtitles, meta lines).
        // Forcing full opacity here is the highest-impact single lever
        // for low-vision contrast, applied everywhere at once.
        highContrast ? { opacity: 1 } : undefined,
      ]}
      {...rest}
    />
  );
}

const styles = StyleSheet.create({
  default: {
    fontSize: 16,
    lineHeight: 24,
  },
  defaultSemiBold: {
    fontSize: 16,
    lineHeight: 24,
    fontWeight: '600',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    lineHeight: 32,
  },
  subtitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  link: {
    lineHeight: 30,
    fontSize: 16,
    color: '#0a7ea4',
  },
});
