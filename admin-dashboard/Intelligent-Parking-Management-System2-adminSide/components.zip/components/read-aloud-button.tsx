import { Pressable, StyleSheet } from 'react-native';

import { IconSymbol } from '@/components/ui/icon-symbol';
import { Colors } from '@/constants/theme';
import { useAccessibility } from '@/contexts/accessibility-context';
import { useColorScheme } from '@/hooks/use-color-scheme';

type ReadAloudButtonProps = {
  text: string;
};

export function ReadAloudButton({ text }: ReadAloudButtonProps) {
  const { readAloudEnabled, speak } = useAccessibility();
  const colorScheme = useColorScheme();
  const tint = Colors[colorScheme ?? 'light'].tint;

  if (!readAloudEnabled) return null;

  return (
    <Pressable
      onPress={() => speak(text)}
      accessibilityRole="button"
      accessibilityLabel="Read this screen aloud"
      hitSlop={10}
      style={[styles.button, { backgroundColor: tint }]}>
      <IconSymbol name="speaker.wave.2.fill" size={18} color="#fff" />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
