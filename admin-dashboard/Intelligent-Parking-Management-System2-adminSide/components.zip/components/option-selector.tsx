import { Pressable, StyleSheet, View } from 'react-native';

import { ThemedText } from '@/components/themed-text';
import { Colors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useThemeStyles } from '@/hooks/use-theme-styles';

type Option<T extends string> = {
  value: T;
  label: string;
};

type OptionSelectorProps<T extends string> = {
  options: Option<T>[];
  selected: T;
  onSelect: (value: T) => void;
};

export function OptionSelector<T extends string>({ options, selected, onSelect }: OptionSelectorProps<T>) {
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'light'];
  const { borderColor } = useThemeStyles();

  return (
    <View style={styles.row}>
      {options.map((option) => {
        const isSelected = option.value === selected;
        return (
          <Pressable
            key={option.value}
            onPress={() => onSelect(option.value)}
            accessibilityRole="button"
            accessibilityState={{ selected: isSelected }}
            accessibilityLabel={option.label}
            style={[
              styles.pill,
              isSelected
                ? { backgroundColor: colors.tint, borderColor: colors.tint }
                : { borderColor },
            ]}>
            <ThemedText style={[styles.pillText, isSelected && styles.pillTextSelected]}>
              {option.label}
            </ThemedText>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  pill: {
    borderWidth: 1.5,
    borderRadius: 20,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  pillText: { fontSize: 14, fontWeight: '600' },
  pillTextSelected: { color: '#fff' },
});
