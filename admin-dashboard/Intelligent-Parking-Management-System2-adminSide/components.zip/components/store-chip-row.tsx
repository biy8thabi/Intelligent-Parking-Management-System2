import { StyleSheet, View } from 'react-native';

import { ThemedText } from '@/components/themed-text';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { Colors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';

type StoreChipRowProps = {
  stores: string[];
};

export function StoreChipRow({ stores }: StoreChipRowProps) {
  const colorScheme = useColorScheme();
  const tint = Colors[colorScheme ?? 'light'].tint;

  return (
    <View style={styles.wrap}>
      {stores.map((store) => (
        <View key={store} style={[styles.chip, { borderColor: tint }]}>
          <IconSymbol name="bag.fill" size={14} color={tint} />
          <ThemedText style={[styles.chipText, { color: tint }]}>{store}</ThemedText>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderWidth: 1,
    borderRadius: 20,
    paddingVertical: 6,
    paddingHorizontal: 12,
  },
  chipText: { fontSize: 13, fontWeight: '600' },
});
