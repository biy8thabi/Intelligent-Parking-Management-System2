import { useState } from 'react';
import { Pressable, StyleSheet, TextInput, type TextInputProps, View } from 'react-native';

import { ThemedText } from '@/components/themed-text';
import { Colors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useThemeStyles } from '@/hooks/use-theme-styles';

type FormTextFieldProps = Omit<TextInputProps, 'style' | 'secureTextEntry'> & {
  label: string;
  error?: string;
  /** Renders a Show/Hide toggle and manages secure text entry internally. */
  isPassword?: boolean;
};

export function FormTextField({ label, error, isPassword, ...rest }: FormTextFieldProps) {
  const [hidden, setHidden] = useState(true);
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'light'];
  const { borderColor } = useThemeStyles();

  return (
    <View style={styles.container}>
      <ThemedText style={styles.label}>{label}</ThemedText>
      <View style={[styles.inputWrapper, { borderColor }, error ? styles.inputWrapperError : undefined]}>
        <TextInput
          {...rest}
          secureTextEntry={isPassword ? hidden : false}
          placeholderTextColor="#9BA1A6"
          style={[styles.input, { color: colors.text }]}
          accessibilityLabel={label}
          accessibilityHint={error}
        />
        {isPassword && (
          <Pressable
            onPress={() => setHidden((prev) => !prev)}
            accessibilityRole="button"
            accessibilityLabel={hidden ? 'Show password' : 'Hide password'}
            hitSlop={10}>
            <ThemedText style={[styles.toggle, { color: colors.tint }]}>
              {hidden ? 'Show' : 'Hide'}
            </ThemedText>
          </Pressable>
        )}
      </View>
      {error ? <ThemedText style={styles.errorText}>{error}</ThemedText> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginBottom: 18 },
  label: { fontSize: 15, marginBottom: 6, fontWeight: '500' },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 14,
    minHeight: 52,
  },
  inputWrapperError: { borderColor: '#DC2626' },
  input: { flex: 1, fontSize: 16, paddingVertical: 12 },
  toggle: { fontWeight: '600', fontSize: 15, marginLeft: 8 },
  errorText: { color: '#DC2626', fontSize: 13, marginTop: 4 },
});
