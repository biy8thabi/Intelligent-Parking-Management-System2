import { Pressable, ScrollView, StyleSheet } from 'react-native';

import { ThemedText } from '@/components/themed-text';
import { Colors } from '@/constants/theme';
import type { MallFloor } from '@/constants/mall-data';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useThemeStyles } from '@/hooks/use-theme-styles';

type FloorSelectorProps = {
  floors: MallFloor[];
  selectedFloorId: string;
  onSelect: (floorId: string) => void;
};

export function FloorSelector({ floors, selectedFloorId, onSelect }: FloorSelectorProps) {
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'light'];
  const { borderColor } = useThemeStyles();

  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.row}>
      {floors.map((floor) => {
        const isSelected = floor.id === selectedFloorId;
        return (
          <Pressable
            key={floor.id}
            onPress={() => onSelect(floor.id)}
            accessibilityRole="button"
            accessibilityLabel={`${floor.label}, ${floor.sublabel}`}
            accessibilityState={{ selected: isSelected }}
            style={[
              styles.tab,
              isSelected
                ? { backgroundColor: colors.tint, borderColor: colors.tint }
                : { borderColor },
            ]}>
            <ThemedText style={[styles.tabLabel, isSelected && styles.tabLabelSelected]}>
              {floor.label}
            </ThemedText>
            <ThemedText
              style={[styles.tabSublabel, isSelected ? styles.tabSublabelSelected : { opacity: 0.6 }]}>
              {floor.sublabel}
            </ThemedText>
          </Pressable>
        );
      })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  row: { gap: 10, paddingRight: 8 },
  tab: {
    borderWidth: 1.5,
    borderRadius: 14,
    paddingVertical: 10,
    paddingHorizontal: 16,
    minWidth: 96,
  },
  tabLabel: { fontSize: 18, fontWeight: '800' },
  tabLabelSelected: { color: '#fff' },
  tabSublabel: { fontSize: 11, marginTop: 2 },
  tabSublabelSelected: { color: '#fff', opacity: 0.9 },
});
