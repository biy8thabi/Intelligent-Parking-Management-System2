import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';

import { calculateFee } from '@/utils/session-billing';

// A ticket is issued the moment a spot is reserved and carries through
// unchanged into the active session and the exit flow — the same QR
// the driver saw at entry is what gets scanned again on the way out.

export type PendingReservation = {
  floorLabel: string; // e.g. "P1 · Basement Parking"
  bayLabel: string; // e.g. "P1-014"
  ticketCode: string;
};

export type ActiveSession = {
  floorLabel: string;
  bayLabel: string;
  ticketCode: string;
  entryTimestamp: number; // set only once the QR is scanned at the gate
};

export type PendingExit = {
  floorLabel: string;
  bayLabel: string;
  ticketCode: string;
  entryTimestamp: number;
  exitTimestamp: number; // frozen the moment "End Session" was tapped
  durationMs: number;
  fee: number;
};

export type CompletedSession = PendingExit & { id: string };

type SessionContextValue = {
  pendingReservation: PendingReservation | null;
  activeSession: ActiveSession | null;
  pendingExit: PendingExit | null;
  completedSessions: CompletedSession[];
  /** Driver picks a spot on Find Parking — issues a ticket, doesn't start the session yet. */
  reserveSpot: (floorLabel: string, bayLabel: string) => void;
  /** QR scanned at the gate on the way in — this actually starts the session. */
  confirmEntry: () => void;
  /** Driver taps "End Session" — freezes duration/fee, doesn't close the session yet. */
  endSession: () => void;
  /** QR scanned at the boom gate on the way out — closes the session and files it in history. */
  confirmExit: () => void;
};

const SessionContext = createContext<SessionContextValue | undefined>(undefined);

function generateTicketCode(issuedAt: number): string {
  const year = new Date(issuedAt).getFullYear();
  const suffix = String(issuedAt % 10000).padStart(4, '0');
  return `PKG-${year}-${suffix}`;
}

export function SessionProvider({ children }: { children: ReactNode }) {
  const [pendingReservation, setPendingReservation] = useState<PendingReservation | null>(null);
  const [activeSession, setActiveSession] = useState<ActiveSession | null>(null);
  const [pendingExit, setPendingExit] = useState<PendingExit | null>(null);
  const [completedSessions, setCompletedSessions] = useState<CompletedSession[]>([]);

  const reserveSpot = useCallback((floorLabel: string, bayLabel: string) => {
    setPendingReservation({ floorLabel, bayLabel, ticketCode: generateTicketCode(Date.now()) });
  }, []);

  const confirmEntry = useCallback(() => {
    setPendingReservation((pending) => {
      if (!pending) return pending;
      setActiveSession({ ...pending, entryTimestamp: Date.now() });
      return null;
    });
  }, []);

  const endSession = useCallback(() => {
    setActiveSession((active) => {
      if (!active) return active;
      const exitTimestamp = Date.now();
      const durationMs = exitTimestamp - active.entryTimestamp;
      setPendingExit({
        floorLabel: active.floorLabel,
        bayLabel: active.bayLabel,
        ticketCode: active.ticketCode,
        entryTimestamp: active.entryTimestamp,
        exitTimestamp,
        durationMs,
        fee: calculateFee(durationMs),
      });
      return null;
    });
  }, []);

  const confirmExit = useCallback(() => {
    setPendingExit((pending) => {
      if (!pending) return pending;
      setCompletedSessions((prev) => [{ ...pending, id: pending.ticketCode }, ...prev]);
      return null;
    });
  }, []);

  const value = useMemo(
    () => ({
      pendingReservation,
      activeSession,
      pendingExit,
      completedSessions,
      reserveSpot,
      confirmEntry,
      endSession,
      confirmExit,
    }),
    [pendingReservation, activeSession, pendingExit, completedSessions, reserveSpot, confirmEntry, endSession, confirmExit]
  );

  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
}

export function useSession(): SessionContextValue {
  const ctx = useContext(SessionContext);
  if (!ctx) {
    throw new Error('useSession must be called within a SessionProvider (check app/_layout.tsx)');
  }
  return ctx;
}
