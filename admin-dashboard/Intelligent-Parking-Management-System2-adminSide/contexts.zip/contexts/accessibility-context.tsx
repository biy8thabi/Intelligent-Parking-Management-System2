import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { useColorScheme as useDeviceColorScheme } from 'react-native';
import * as Speech from 'expo-speech';

// NOTE: these settings are in-memory only and reset when the app
// reloads — there's no persistence layer (e.g. AsyncStorage) anywhere
// in this project yet. Worth adding in a later phase if these should
// survive a restart.

export type ThemeOverride = 'light' | 'dark' | 'system';
export type FontScaleOption = 'default' | 'large' | 'extraLarge';

const FONT_SCALE_VALUES: Record<FontScaleOption, number> = {
  default: 1,
  large: 1.15,
  extraLarge: 1.3,
};

type AccessibilityContextValue = {
  themeOverride: ThemeOverride;
  setThemeOverride: (value: ThemeOverride) => void;
  colorScheme: 'light' | 'dark'; // effective scheme after applying the override
  fontScaleOption: FontScaleOption;
  setFontScaleOption: (value: FontScaleOption) => void;
  fontScaleMultiplier: number;
  highContrast: boolean;
  setHighContrast: (value: boolean) => void;
  readAloudEnabled: boolean;
  setReadAloudEnabled: (value: boolean) => void;
  speak: (text: string) => void;
  stopSpeaking: () => void;
};

const AccessibilityContext = createContext<AccessibilityContextValue | undefined>(undefined);

export function AccessibilityProvider({ children }: { children: ReactNode }) {
  // Mirrors the hydration-safe pattern the Expo web starter used for
  // useColorScheme — harmless extra render on native, prevents a
  // light/dark mismatch flash on web's static rendering.
  const [hasHydrated, setHasHydrated] = useState(false);
  useEffect(() => setHasHydrated(true), []);
  const rawDeviceScheme = useDeviceColorScheme();
  const deviceScheme: 'light' | 'dark' = hasHydrated && rawDeviceScheme === 'dark' ? 'dark' : 'light';

  const [themeOverride, setThemeOverride] = useState<ThemeOverride>('system');
  const [fontScaleOption, setFontScaleOption] = useState<FontScaleOption>('default');
  const [highContrast, setHighContrast] = useState(false);
  const [readAloudEnabled, setReadAloudEnabled] = useState(false);

  const colorScheme: 'light' | 'dark' = themeOverride === 'system' ? deviceScheme : themeOverride;

  const speak = useCallback((text: string) => {
    Speech.stop();
    Speech.speak(text, { rate: 0.95 });
  }, []);

  const stopSpeaking = useCallback(() => Speech.stop(), []);

  const value = useMemo(
    () => ({
      themeOverride,
      setThemeOverride,
      colorScheme,
      fontScaleOption,
      setFontScaleOption,
      fontScaleMultiplier: FONT_SCALE_VALUES[fontScaleOption],
      highContrast,
      setHighContrast,
      readAloudEnabled,
      setReadAloudEnabled,
      speak,
      stopSpeaking,
    }),
    [themeOverride, colorScheme, fontScaleOption, highContrast, readAloudEnabled, speak, stopSpeaking]
  );

  return <AccessibilityContext.Provider value={value}>{children}</AccessibilityContext.Provider>;
}

export function useAccessibility(): AccessibilityContextValue {
  const ctx = useContext(AccessibilityContext);
  if (!ctx) {
    throw new Error('useAccessibility must be called within an AccessibilityProvider (check app/_layout.tsx)');
  }
  return ctx;
}
