import { Colors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';

/**
 * Card borders and muted surfaces were originally hardcoded to light-mode
 * greys in every StyleSheet. StyleSheet.create is static, so those can't
 * react to the theme — this hook returns the theme-aware values to spread
 * inline over the static style (e.g. `style={[styles.card, { borderColor }]}`).
 */
export function useThemeStyles() {
  const colorScheme = useColorScheme();
  const colors = Colors[colorScheme ?? 'light'];

  return {
    borderColor: colors.border,
    surfaceColor: colors.surface,
    /** Convenience for the common card case. */
    cardBorder: { borderColor: colors.border },
    /** Convenience for muted panel backgrounds. */
    surface: { backgroundColor: colors.surface },
  };
}
