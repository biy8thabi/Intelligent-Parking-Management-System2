import { useEffect, useState } from 'react';

/**
 * Forces the calling component to re-render every `intervalMs`. Used
 * wherever we display an elapsed duration computed from a stored
 * timestamp (e.g. "1h 24m" since entry) — the timestamp itself never
 * changes, so without this the displayed duration would go stale.
 */
export function useNowTick(intervalMs: number): void {
  const [, forceRender] = useState(0);

  useEffect(() => {
    const id = setInterval(() => forceRender((n) => n + 1), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
}
