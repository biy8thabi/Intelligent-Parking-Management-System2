import { useAccessibility } from '@/contexts/accessibility-context';

/**
 * Every screen in the app calls this hook exactly as before — the
 * manual light/dark/system override now lives in AccessibilityContext,
 * so this just forwards the effective scheme. No call site needed to
 * change for the theme toggle to reach every page.
 */
export function useColorScheme(): 'light' | 'dark' {
  return useAccessibility().colorScheme;
}
